import { create } from 'zustand';
import { Post } from '../types/community';

interface CommunityState {
  posts: Post[];
  addPost: (post: Omit<Post, 'id' | 'createdAt' | 'updatedAt' | 'upvotes' | 'comments'>) => void;
  addComment: (postId: string, userId: string, content: string) => void;
  upvotePost: (postId: string) => void;
}

const useCommunityStore = create<CommunityState>((set) => ({
  posts: [],
  addPost: (post) =>
    set((state) => ({
      posts: [
        {
          ...post,
          id: Math.random().toString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          upvotes: 0,
          comments: [],
        },
        ...state.posts,
      ],
    })),
  addComment: (postId, userId, content) =>
    set((state) => ({
      posts: state.posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              comments: [
                ...post.comments,
                {
                  id: Math.random().toString(),
                  userId,
                  content,
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                },
              ],
            }
          : post
      ),
    })),
  upvotePost: (postId) =>
    set((state) => ({
      posts: state.posts.map((post) =>
        post.id === postId
          ? { ...post, upvotes: post.upvotes + 1 }
          : post
      ),
    })),
}));

export default useCommunityStore;