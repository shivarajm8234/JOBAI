import { create } from 'zustand';
import { Resume } from '../types/resume';

interface ResumeState {
  resume: Resume;
  updateResume: (updates: Partial<Resume>) => void;
  atsScore: number;
  generateATSScore: () => void;
}

const INITIAL_RESUME: Resume = {
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    location: '',
  },
  education: [],
  experience: [],
  skills: [],
  certifications: [],
};

const useResumeStore = create<ResumeState>((set) => ({
  resume: INITIAL_RESUME,
  atsScore: 0,
  updateResume: (updates) =>
    set((state) => ({
      resume: { ...state.resume, ...updates },
    })),
  generateATSScore: () =>
    set((state) => {
      // Simple scoring algorithm
      let score = 0;
      const resume = state.resume;

      // Personal info completeness
      score += Object.values(resume.personalInfo).filter(Boolean).length * 5;

      // Education
      score += resume.education.length * 10;

      // Experience
      score += resume.experience.length * 15;

      // Skills
      score += resume.skills.length * 5;

      // Certifications
      score += resume.certifications.length * 8;

      // Normalize to 0-100
      score = Math.min(Math.round(score), 100);

      return { atsScore: score };
    }),
}));

export default useResumeStore;