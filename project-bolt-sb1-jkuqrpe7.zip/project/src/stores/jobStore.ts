import { create } from 'zustand';
import { Job, JobFilters } from '../types/job';

interface JobState {
  jobs: Job[];
  filters: JobFilters;
  savedJobs: string[];
  setFilters: (filters: Partial<JobFilters>) => void;
  toggleSavedJob: (jobId: string) => void;
}

const MOCK_JOBS: Job[] = [
  {
    id: '1',
    title: 'Software Engineer',
    company: 'Tech Corp',
    location: 'New York, NY',
    salary: '$120,000 - $150,000',
    type: 'non-government',
    experience: '3-5 years',
    remote: true,
    description: 'Looking for a skilled software engineer...',
    requirements: [
      'Bachelor\'s degree in Computer Science',
      '3+ years of experience with React',
      'Strong problem-solving skills',
    ],
    deadline: '2024-04-30',
    tags: ['React', 'TypeScript', 'Node.js'],
  },
  {
    id: '2',
    title: 'Data Analyst',
    company: 'Government Agency',
    location: 'Washington, DC',
    salary: '$80,000 - $100,000',
    type: 'government',
    experience: '2-4 years',
    remote: false,
    description: 'Seeking a data analyst to join our team...',
    requirements: [
      'Master\'s degree in Statistics or related field',
      'Experience with Python and SQL',
      'Security clearance required',
    ],
    deadline: '2024-05-15',
    tags: ['Python', 'SQL', 'Data Analysis'],
  },
];

const useJobStore = create<JobState>((set) => ({
  jobs: MOCK_JOBS,
  filters: {
    search: '',
    type: '',
    location: '',
    remote: false,
    experience: '',
  },
  savedJobs: [],
  setFilters: (newFilters) =>
    set((state) => ({
      filters: { ...state.filters, ...newFilters },
    })),
  toggleSavedJob: (jobId) =>
    set((state) => ({
      savedJobs: state.savedJobs.includes(jobId)
        ? state.savedJobs.filter((id) => id !== jobId)
        : [...state.savedJobs, jobId],
    })),
}));

export default useJobStore;