import React from 'react';
import { BarChart, Users, Briefcase, Calendar } from 'lucide-react';

const Dashboard = () => {
  const stats = [
    { label: 'Applications Submitted', value: '24', icon: BarChart },
    { label: 'Interviews Scheduled', value: '3', icon: Calendar },
    { label: 'Saved Jobs', value: '12', icon: Briefcase },
    { label: 'Network Connections', value: '156', icon: Users },
  ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <Icon className="h-8 w-8 text-blue-600" />
                <span className="text-3xl font-bold text-gray-900">{stat.value}</span>
              </div>
              <h3 className="text-gray-600 font-medium">{stat.label}</h3>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Applications</h2>
          <div className="space-y-4">
            {[
              { company: 'Tech Corp', role: 'Senior Developer', status: 'Under Review' },
              { company: 'StartUp Inc', role: 'Full Stack Engineer', status: 'Interviewing' },
              { company: 'Big Tech Co', role: 'Frontend Developer', status: 'Applied' },
            ].map((application, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium text-gray-900">{application.company}</h3>
                  <p className="text-sm text-gray-600">{application.role}</p>
                </div>
                <span className="px-3 py-1 text-sm font-medium text-blue-600 bg-blue-100 rounded-full">
                  {application.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Upcoming Interviews</h2>
          <div className="space-y-4">
            {[
              { company: 'Tech Corp', date: 'Tomorrow, 2:00 PM', type: 'Technical' },
              { company: 'StartUp Inc', date: 'Next Week, 11:00 AM', type: 'Initial' },
            ].map((interview, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium text-gray-900">{interview.company}</h3>
                  <p className="text-sm text-gray-600">{interview.date}</p>
                </div>
                <span className="px-3 py-1 text-sm font-medium text-green-600 bg-green-100 rounded-full">
                  {interview.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;