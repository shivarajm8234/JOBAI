import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import JobListings from './pages/JobListings';
import JobDetails from './pages/JobDetails';
import ResumeBuilder from './pages/ResumeBuilder';
import ChatBot from './pages/ChatBot';
import AlertSettings from './pages/AlertSettings';
import Interviews from './pages/Interviews';
import Community from './pages/Community';
import AdminDashboard from './pages/AdminDashboard';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="jobs" element={<JobListings />} />
          <Route path="jobs/:id" element={<JobDetails />} />
          <Route path="resume-builder" element={<ResumeBuilder />} />
          <Route path="chat" element={<ChatBot />} />
          <Route path="alerts" element={<AlertSettings />} />
          <Route path="interviews" element={<Interviews />} />
          <Route path="community" element={<Community />} />
          <Route
            path="admin"
            element={
              <ProtectedRoute requireAdmin>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;