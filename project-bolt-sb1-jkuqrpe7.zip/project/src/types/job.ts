export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  type: 'government' | 'non-government';
  experience: string;
  remote: boolean;
  description: string;
  requirements: string[];
  deadline: string;
  tags: string[];
}

export interface JobFilters {
  search: string;
  type: string;
  location: string;
  remote: boolean;
  experience: string;
}